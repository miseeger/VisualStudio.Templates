﻿namespace $safeprojectname$.Data.HubModels
{
    public class OrderCheckResult
    {
        public bool New { get; set; }
        public string Update { get; set; }
        public bool Finished { get; set; }
    }
}