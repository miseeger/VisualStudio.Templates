#Only some notes

##How to do Package Updates:

To update the VueClient-Project use the Vue CLI 3.0 UI and update all the plugins and 
packages from within the UI. Then check for package updates with npm-check-updates 
(https://www.npmjs.com/package/npm-check-updates):

- npm install -g npm-check-updates 

- ncu -u

- npm install