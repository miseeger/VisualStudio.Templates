﻿using System.Collections;
using System.Collections.Generic;

namespace $safeprojectname$.Data.ViewModels
{
    public class TopTrackViewModel
    {
        public int TrackRank { get; set; }
        public string Song { get; set; }
        public string Album { get; set; }
        public string Artist { get; set; }
    }
}