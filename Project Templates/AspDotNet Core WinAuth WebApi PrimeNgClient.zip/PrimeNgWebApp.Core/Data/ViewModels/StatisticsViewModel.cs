﻿namespace $safeprojectname$.Data.ViewModels
{
    public class StatisticsViewModel
    {
        public int AlbumCount { get; set; }
        public int SongCount { get; set; }
        public int ArtistCount { get; set; }
        public int PlayLength { get; set; }
    }
}