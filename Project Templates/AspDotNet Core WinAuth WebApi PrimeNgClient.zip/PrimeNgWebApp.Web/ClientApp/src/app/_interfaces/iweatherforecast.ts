export interface IWeatherforecast {
    date: string;
    temperatureC: number;
    temperatureF: number;
    summary: string;
}
