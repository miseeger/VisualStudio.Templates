export interface ITopTrack {
    trackRank: number;
    song: string;
    album: string;
    artist: string;
}
