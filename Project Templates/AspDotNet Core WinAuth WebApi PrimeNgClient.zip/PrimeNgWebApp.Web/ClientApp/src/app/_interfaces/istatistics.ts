export interface IStatistics {
    albumCount: number;
    songCount: number;
    artistCount: number;
    playLength: number;
}
