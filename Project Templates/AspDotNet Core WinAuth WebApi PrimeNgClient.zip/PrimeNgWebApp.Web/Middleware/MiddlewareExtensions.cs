﻿using Microsoft.AspNetCore.Builder;

namespace $safeprojectname$.Middleware
{

    public static class MiddlewareExtensions
    {
        public static IApplicationBuilder UseRequestLogging(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<RequestLogMiddleware>();

        }

        public static IApplicationBuilder Use$safeprojectname$Ping(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<$safeprojectname$PingMiddleware>();
        }
    }

}
