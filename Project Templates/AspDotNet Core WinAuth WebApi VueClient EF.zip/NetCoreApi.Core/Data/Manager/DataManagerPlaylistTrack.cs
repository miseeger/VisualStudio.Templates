namespace $safeprojectname$.Data.Manager
{
    public partial class DataManager : IDataManager
    {
        
    }
}