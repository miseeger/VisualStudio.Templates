<template>
    <div class="about">
        <h1>This is the about page</h1>This app was built with the
        <a
            target="_blank"
            href="https://github.com/miseeger/VisualStudio.Templates"
        >
            <b>AspDotNet Core WinAuth WebApi VueClient EF</b>
        </a> project template for Visual Studio by
        <a
            target="_blank"
            href="https://twitter.com/MiSeeger"
        >@miseeger</a>
    </div>
</template>