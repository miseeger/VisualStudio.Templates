namespace $safeprojectname$.Interfaces
{

	public interface INPocoDbService
    {
        INPocoDb CreateDb();
    }

}
