using NPoco;

namespace $safeprojectname$.Interfaces
{

    public interface INPocoDb : IDatabase
	{
	}

}