using NPoco;

namespace $safeprojectname$.Data.Interface
{

    public interface IDataService : IDatabase
    {
        // Declare special interface to extend IDatabase if needed
    }

}
