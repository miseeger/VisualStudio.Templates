declare module 'vue-form-generator' {
    const VueFormGenerator: any;
    export default VueFormGenerator;
}