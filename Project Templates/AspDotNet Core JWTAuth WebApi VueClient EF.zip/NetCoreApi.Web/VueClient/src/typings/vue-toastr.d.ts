declare module 'vue-toastr' {
    const VueToastr: any;
    export default VueToastr;
}
