export interface IResetPasswordPayload {
    Code: string;
    Email: string;
    Password: string;
    ConfirmPassword: string;
}
