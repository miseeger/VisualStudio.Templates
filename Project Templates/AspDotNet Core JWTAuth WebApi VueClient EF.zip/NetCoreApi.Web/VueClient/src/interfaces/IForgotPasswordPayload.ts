export interface IForgotPasswordPayload {
    Email: string;
}
