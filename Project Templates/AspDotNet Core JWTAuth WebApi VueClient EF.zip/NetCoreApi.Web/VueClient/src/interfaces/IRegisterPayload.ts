export interface IRegisterPayload {
    Username: string;
    Email: string;
    Password: string;
    ConfirmPassword: string;
}
