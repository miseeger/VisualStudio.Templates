export interface ILoginPayload {
    Email: string;
    Password: string;
}
