export interface IErrors {
    error: any[];
}