export interface IToken {
    access_token: string;
    access_token_expiration: string;
    userName: string;
}
