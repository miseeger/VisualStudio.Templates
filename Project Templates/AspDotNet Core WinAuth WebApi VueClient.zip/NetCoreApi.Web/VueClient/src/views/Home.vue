<template>
  <div class="home">
    <img alt="Vue logo" src="../assets/logo.png">
    <HelloWorld msg="Guude!!! Welcome to Your Vue.js + TypeScript App"/>
  </div>
</template>

<script lang="ts">
    import Vue from 'vue';
    import HelloWorld from '@/components/HelloWorld.vue'; // @ is an alias to /src

    export default Vue.extend({
        components: {
            HelloWorld
        }
    })
</script>
