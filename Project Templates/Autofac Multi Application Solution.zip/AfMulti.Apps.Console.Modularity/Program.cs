﻿namespace $safeprojectname$
{
	class Program
	{
		public static void Main(string[] args)
		{
			var bootstrapper = new ConsoleBootstrapper();
			bootstrapper.Run(args);
		}
	}
}