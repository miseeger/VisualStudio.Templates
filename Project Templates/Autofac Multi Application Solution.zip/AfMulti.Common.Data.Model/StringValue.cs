﻿using System;
using System.Collections.Generic;

namespace $safeprojectname$
{

	public class StringValue
	{

		public int Id { get; set; }
		public string Value { get; set; }

	}

}